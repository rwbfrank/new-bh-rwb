<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

dynamic_sidebar(); ?>
